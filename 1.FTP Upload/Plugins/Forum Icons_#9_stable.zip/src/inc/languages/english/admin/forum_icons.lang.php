<?php
$l['ficons_title'] = "Forum Icons";
$l['ficons_manage'] = "Manage Forum Icons";
$l['ficons_forum'] = "Forum";
$l['ficons_image'] = "Image URL";
$l['ficons_preview'] = "Preview";
$l['ficons_no_forum'] = "There aren't forums to add an icon.";
$l['ficons_no_preview'] = "Preview not available";
$l['ficons_save'] = "Save Icons";
$l['ficons_reset'] = "Reset";
$l['ficons_not_saved'] = "Plugin Forum Icons is not installed.";
$l['ficons_saved'] = "Forum icons has been updated.";
$l['ficons_log'] = "Forum icons updated";
