<?php
$l['ficons_title'] = "Icone Forum";
$l['ficons_manage'] = "Gestisci Icone Forum";
$l['ficons_forum'] = "Forum";
$l['ficons_image'] = "Indirizzo Immagine";
$l['ficons_preview'] = "Anteprima";
$l['ficons_no_forum'] = "Non ci sono forum a cui aggiungere un icona.";
$l['ficons_no_preview'] = "Anteprima non disponibile";
$l['ficons_save'] = "Salva Icone";
$l['ficons_reset'] = "Resetta";
$l['ficons_not_saved'] = "Il plugin Forum Icons non è installato.";
$l['ficons_saved'] = "Le icone dei forum sono state aggiornate.";
$l['ficons_log'] = "Icone forum aggiornate";
