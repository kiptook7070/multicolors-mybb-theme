# [Forum Icons](http://www.chack1172.altervista.org/Projects/MyBB-18/Forum-Icons.html)
Category: [MyBB 1.8](http://www.chack1172.altervista.org/Projects/MyBB-18/)
Author: [chack1172](http://en.chack1172.altervista.org)

Forum Icons is a plugin that allows you to add an icon to each forum on your MyBB's copy.

### Installation
1. Upload contents of the folder 'src' to your board directory
2. Go to `ACP > Plugins > Install & Activate 'Forum Icons'`

### Managemant
To manage forum icons you have to go to `Forum & Posts -> Forum Icons`.
