# [Newpoints Awards](http://www.chack1172.altervista.org/Progetti/MyBB-18/Icone-Forum.html)
Category: [MyBB 1.8](http://www.chack1172.altervista.org/Progetti/MyBB-18/)
Author: [chack1172](http://it.chack1172.altervista.org)

Icone Forum � un plugin che ti permette di aggiungere un'icona ad ogni forum nella tua copia di MyBB.

### Installazione
1. Carica il contenuto della cartella 'src' nella cartella della tua board
2. Vai in `ACP > Plugin > Installa e Attiva 'Icone Forum'`

### Gestione
Per gestire le icone vai in `Forum & Messaggi -> Icone Forum`.
